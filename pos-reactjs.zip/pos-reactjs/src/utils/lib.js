import products from '../data/products.json';

export const getAllProductIds = () => products.map(p => p.id);

export const getProductbyId = id => {
  if(!id) return {};
  return products.find(p => p.id === parseInt(id))
};

export const addOrUpdateItem = (items, product, quantity) => {
  const index = items.findIndex(item => item.id === product.id);
  let newItems;

  if(index === -1){ // add
    newItems = [ ...items, 
      {
        ...product,
        quantity
      }
    ];
  } else { // update
    newItems = [...items];
    newItems[index].quantity += quantity;
  }
  return newItems;
}

export const removeItem = (items, removeItem) => {
  return items.filter(item => item.id !== removeItem.id);
}

export const removeBulkItems = (items, checkedItems) => {
  return items.filter(item => !checkedItems.some(
    checkedItem => checkedItem.id === item.id
  ));
}

export const setItemQuantity = (items, updateItem, newQuantity) => {
  const index = items.findIndex(item => item.id === updateItem.id);
  const newItems = [...items];
  newItems[index].quantity = parseInt(newQuantity);
  return newItems;
}