import { useState, useEffect } from 'react';
import {getAllProductIds, getProductbyId} from '../utils/lib';

const INIT_PRODUCT = {
  id: '',
  title: '',
  units: '',
  unitPrice: ''
};

export const SalesInput = (props) => {
  let [allProductIds, setAllproductsIds] = useState([]);
  const [selectedPId, setSelectedPId] = useState('');
  let [product, setProduct] = useState(INIT_PRODUCT);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {    
    const ids = getAllProductIds();
    setAllproductsIds(ids);
    // console.log("allProductIds", ids);
  }, []);

  const quantityHandler = (e) => {
    setQuantity(parseInt(e.target.value))
  }
 
  const handleAddProduct = () => {
    props.addSalesItem(product, quantity);
    handleClear();
  }

  const handlePIdChange = e => {
    const id = e.target.value;
    if(!id){
      handleClear();
      return;
    }
    setSelectedPId(id);
    
    const product = getProductbyId(id);
    setProduct(product);
    console.log("Product.in", product);
  }

  const handleClear = () => {
    setProduct(INIT_PRODUCT);
    setSelectedPId('');
    setQuantity(1);
  }

  return (
    <div className="card text-bg-info m-3 rounded-pill">
      <div className="card-body">   
          <div className="row  align-items-center">
            <div className="col">
              <select className="form-select" onChange={handlePIdChange} value={selectedPId} autoFocus>
              <option key={"option-0"} value=""></option>
                {
                  allProductIds.map(id => <option key={id} >{id}</option>)
                }
              </select>

            </div>
            <div className="col" >
              <input className="form-control" type="text" name="productTitle" disabled={"active"} placeholder="Product Title" value={product.title}/>
            </div>

            <div className="col" >
              <input className="form-control" type="number" name="quantity" min={1} onChange={quantityHandler} placeholder="quantity" value={quantity}/>
            </div>

            <div className="col" >
              <input className="form-control" type="number"name="unitPrice" disabled={"active"} placeholder="unitPrice" value={product.unitPrice}/>
            </div>

            <div className="col" >
              <button  
                className="btn btn-primary px-5" 
                disabled={!selectedPId}
                onClick={handleAddProduct}>
                Add</button>
            </div>

            <div className="col" >
              <button  
                className="btn btn-warning px-5" 
                onClick={handleClear}>
                  Clear</button>
            </div>
          </div>
      </div>
    </div>
  )
}