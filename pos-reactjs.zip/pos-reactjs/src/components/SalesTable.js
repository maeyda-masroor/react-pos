import {useEffect, useState} from 'react';

export const SalesTable = (props) => {
  const {items, delItem, updateItemQuantity, delBulkItems} = props;

  const [checkedItems, setCheckedItems] = useState([]);
  const [grandTotal, setGrandTotal] = useState(0);

  console.log("SalesTable.in ", items);

  const updateQunatity = (e, item) => {
    updateItemQuantity(item, e.target.value);
  }

  useEffect(() => {
      const total = items.reduce(
        (sum, item) => sum + item.unitPrice * item.quantity, 
        0
      );
      console.log("Grand Total", total);
      setGrandTotal(total);
    }, [items]);

  const handleItemCheck = (e, item) => {
    if(e.target.checked)
      setCheckedItems([...checkedItems, item]);
    else
      setCheckedItems(
        checkedItems.filter(i => i.id !== item.id)
      );
  }

  const handleAllChecked = (e) => {
    if(e.target.checked)
      setCheckedItems([...items]);
    else
      setCheckedItems([]);
  }

  const handleBulkDelete = () => {
    delBulkItems(checkedItems);
    setCheckedItems([]);
  }

  return (
    <>
     {!!checkedItems.length && (
        <span
          role="button" 
          className="badge text-bg-danger"
          onClick={handleBulkDelete}
          cursor="hand"
          >
          delete selected item(s): {checkedItems.length}
        </span>
      )}

    <div className="card m-3">
      <table className="table table-bordered ">
        <thead>
          <tr>
            <th scope="col" className="text-center">
              <input 
                type="checkbox" 
                className="form-check-input"
                checked={
                  checkedItems.length && 
                  checkedItems.length === items.length
                }
                onChange={handleAllChecked}
                /> 
            </th>
            <th scope="col">ID </th>
            <th scope="col">Title</th>
            <th scope="col">Quantity</th>
            <th scope="col">Unit Price</th>
            <th scope="col">Total</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {items.map(item => (
            <tr key={item.id}>
              <td className="text-center">
                <input 
                  type="checkbox" 
                  className="form-check-input"
                  checked={
                    checkedItems.find(i => i.id === item.id)
                  }
                  onChange={
                    (e) => handleItemCheck(e, item)
                    }
                />
              </td>
              <td>{item.id}</td>
              <td>{item.title}</td>
              <td>
                <input 
                  type="number"
                  min={1}
                  value={item.quantity}
                  onChange={e => updateQunatity(e, item)}/>
              </td>
              <td>{item.unitPrice}</td>
              <td>{item.quantity * item.unitPrice}</td>
              <td>
                <button 
                  className="btn btn-danger"
                  onClick={() => delItem(item)}
                  >Delete</button>
              </td>
            </tr>
          ))}
          <tr>
            <td colSpan="5" className="text-end text-success"><h2>Grand Total</h2></td>
            <td colSpan="2" className="bg-success text-white rounded-pill text-center">
              <h2>Rs. {grandTotal}</h2>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    </>
  )
}