import { useEffect, useState} from "react";
import { CustomerInfo } from "./components/CustomerInfo";
import Navbar from "./components/navbar";
import { PrintBill } from "./components/PrintBill";
import { SalesInput } from './components/SalesInput';
import { SalesTable } from "./components/SalesTable";
import { 
  addOrUpdateItem, removeItem, setItemQuantity, removeBulkItems 
} from "./utils/lib";

const INIT_SALES = {
  customer: {},
  payment: {},
  items: []
};

function App() {
  const [sales, setSales] = useState(INIT_SALES);

  useEffect(() => {
    const keyDownHandler = event => {
      if (event.key === "Escape") {
        setSales(INIT_SALES);
      }
    }
    document.addEventListener("keydown", keyDownHandler);

    return () => {
      document.removeEventListener("keydown", keyDownHandler);
    };
  }, []);

  const addSalesItem = (product, quantity) => {
    let items = addOrUpdateItem(sales.items, product, quantity);
    setSales({...sales, items});
  }

  const delItem = (item) => {
    const items = removeItem(sales.items, item);
    setSales({...sales, items});
  }

  const delBulkItems = (checkedItems) => {
    const items = removeBulkItems(sales.items, checkedItems);
    setSales({...sales, items});
  }

  const updateItemQuantity = (item, newQuantity) => {
    const items = setItemQuantity(sales.items, item, newQuantity);
    setSales({...sales, items});
  }

  return (
    <div className="container">
      <Navbar />
      <SalesInput addSalesItem={addSalesItem}/>
      <SalesTable 
        items={sales.items} 
        delItem={delItem}
        updateItemQuantity={updateItemQuantity}
        delBulkItems={delBulkItems}
        />
      <CustomerInfo />
      <PrintBill />
    </div>
  )
}

export default App;